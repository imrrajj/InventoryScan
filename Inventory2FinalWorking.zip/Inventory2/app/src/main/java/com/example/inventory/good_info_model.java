package com.example.inventory;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.inventory.com.a2a.inventory.bean.ShoppingCart;
import com.example.inventory.com.a2a.inventory.bean.ShoppingCartItem;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;

public class good_info_model extends AppCompatActivity {
    TextView image,name,id,model,sku,stock,description,min,price;
    EditText quantity;
    Button back;
    Button add;
    String p_name, p_id, p_model, p_sku,p_stock, p_quantity,p_price, p_min, p_description,p_image;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_good_info_model);
        Intent intent = getIntent();
        Bundle bundle = intent.getBundleExtra("product");
        p_name = bundle.getString("name");
        p_id = bundle.getString("product_id");
        p_model = bundle.getString("model");
        p_sku = bundle.getString("sku");
        p_stock = bundle.getString("quantity");
        p_description = bundle.getString("description");
        p_price =bundle.getString("price");
        p_min = bundle.getString("minimum");
        p_image = bundle.getString("image");


        name = (TextView)findViewById(R.id.product_name_byModel);
        id = (TextView)findViewById(R.id.product_id_byModel);
        model = (TextView)findViewById(R.id.product_model_byModel);
        sku = (TextView)findViewById(R.id.product_sku_byModel);
        stock = (TextView)findViewById(R.id.product_stock_byModel);
        description = (TextView)findViewById(R.id.product_description_byModel);
        image = (TextView)findViewById(R.id.product_image_byModel);
        price =(TextView)findViewById(R.id.product_price_byModel);
        min = (TextView)findViewById(R.id.product_min_byModel);
        back = (Button)findViewById(R.id.back_to_menu_btn);
        add = (Button)findViewById(R.id.add_to_cart_btn);

        quantity = (EditText) findViewById(R.id.product_quantity_byModel);

        image.setText(p_image);
        name.setText(p_name);
        id.setText(p_id);
        model.setText(p_model);
        sku.setText(p_sku);
        stock.setText(p_stock);
        price.setText(p_price);
        min.setText(p_min);
        description.setText(p_description);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                backToMenu();
            }
        });

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addProductToCart();
            }
        });
    }
    public void backToMenu(){
         Intent intent = new Intent(good_info_model.this,MainActivity.class);
         startActivity(intent);
    }

    public void addProductToCart(){
         p_quantity = quantity.getText().toString();
         if(p_quantity != "" && p_quantity.matches("[0-9]{1,}")){
            if(Integer.parseInt(p_min) <= Integer.parseInt(p_quantity) && Integer.parseInt(p_quantity) <= Integer.parseInt(p_stock)){

                SharedPreferences sharedPreferences = getSharedPreferences("UserInfo",
                MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                String shopping_cart_id = sharedPreferences.getString("userId","");
                String shopping_cart_str = sharedPreferences.getString(shopping_cart_id,"");
                if (shopping_cart_str == "") {
                    ShoppingCart shoppingCart = new ShoppingCart();
                    List<ShoppingCartItem> shoppingCartItemList = new ArrayList<ShoppingCartItem>();
                    ShoppingCartItem shoppingCartItem = new ShoppingCartItem();
                    shoppingCartItem.setGood_id(p_id);
                    shoppingCartItem.setGood_image(p_image);
                    shoppingCartItem.setGood_name(p_name);
                    shoppingCartItem.setGood_price(p_price);
                    shoppingCartItem.setGood_quantity(p_quantity);
                    shoppingCartItemList.add(shoppingCartItem);
                    shoppingCart.setUserId(sharedPreferences.getString("userId",""));
                    shoppingCart.setToken(sharedPreferences.getString("token",""));
                    shoppingCart.setShoppingCartItemList(shoppingCartItemList);
                    Gson gson = new Gson();
                    shopping_cart_str = gson.toJson(shoppingCart);
                    editor.putString(shopping_cart_id,shopping_cart_str);
                    editor.commit();
                    Toast showToast = Toast.makeText(good_info_model.this,"successful",
                    Toast.LENGTH_SHORT);
                    showToast.show();
                    Intent intent = new Intent(good_info_model.this, MainActivity.class);
                    startActivity(intent);}
                else{
                    Gson gson = new Gson();
                    ShoppingCart shoppingCart = gson.fromJson(shopping_cart_str, ShoppingCart.class);
                    ShoppingCartItem shoppingCartItem = new ShoppingCartItem();
                    List<ShoppingCartItem> shoppingCartItemList = new ArrayList<ShoppingCartItem>();
                    shoppingCartItem.setGood_id(p_id);
                    shoppingCartItem.setGood_image(p_image);
                    shoppingCartItem.setGood_name(p_name);
                    shoppingCartItem.setGood_price(p_price);
                    shoppingCartItem.setGood_quantity(p_quantity);
                    shoppingCartItemList = shoppingCart.getShoppingCartItemList();
                    shoppingCartItemList.add(shoppingCartItem);
                    shoppingCart.setShoppingCartItemList(shoppingCartItemList);
                    shopping_cart_str = gson.toJson(shoppingCart);
                    editor.putString(shopping_cart_id,shopping_cart_str);
                    editor.commit();
                    Toast showToast = Toast.makeText(good_info_model.this,"successful",
                    Toast.LENGTH_SHORT);
                    showToast.show();
                    Intent intent = new Intent(good_info_model.this, MainActivity.class);
                    startActivity(intent);

                }





            }else{
                Toast showToast= Toast.makeText(good_info_model.this,"The quantity must over the min or less than the stock",Toast.LENGTH_SHORT);
                showToast.show();
            }




         }else{
             Toast showToast= Toast.makeText(good_info_model.this,"Input the correct quantity",Toast.LENGTH_SHORT);
             showToast.show();
         }



    }
}
