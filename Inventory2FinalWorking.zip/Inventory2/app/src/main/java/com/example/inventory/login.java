package com.example.inventory;

import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import android.content.SharedPreferences;
import com.example.inventory.com.a2a.inventory.request.LoginRequest;
import com.example.inventory.com.a2a.inventory.retrofitService.UserService;
import com.example.inventory.com.a2a.inventory.bean.User;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import android.content.Intent;
import android.widget.Toast;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

import retrofit2.converter.gson.GsonConverterFactory;

public class login extends AppCompatActivity {

    EditText username;
    EditText password;
    Button login;
    public static final String Base_login_URL = "http://look4computer.a2aweb.net/api/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        String user = new String();
        String pwd = new String();
        username =  findViewById(R.id.login_user_id);
        password = findViewById(R.id.login_user_password);
        login = findViewById(R.id.login_btn);



        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = username.getText().toString();
                String pwd = password.getText().toString();
                if(user != "" && pwd != "") {

                    sendRequest(user,pwd);

                }else {

                    emptyError();
                }
            }
        });
    }

    public void sendRequest(String username, String password){

          Gson gson = new GsonBuilder()
                  .setDateFormat("yyyy-MM-dd'T'HH:mm:ssZ")
                  .create();

            Retrofit retrofit = new Retrofit.Builder()
                    .baseUrl(Base_login_URL)
                    .addConverterFactory(GsonConverterFactory.create(gson))
                    .build();

            UserService userService = retrofit.create(UserService.class);

            Call<User>login = userService.login(new LoginRequest(username, password));

            login.enqueue(new Callback<User>() {
                @Override
                public void onResponse(Call<User> call, Response<User> response) {
                    int statusCode = response.code();
                    User user = response.body();
                    SharedPreferences sharedPreferences = getSharedPreferences("UserInfo",MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("userId", user.getUser_id());
                    editor.putString("message",user.getMessage());
                    editor.putString("token",user.getToken());
                    editor.commit();
                    Intent intent = new Intent(com.example.inventory.login.this,MainActivity.class);
                    startActivity(intent);
                }

                @Override
                public void onFailure(Call<User> call, Throwable t) {
                    combinationError();
                }
            });

    }


    public void combinationError(){
        Toast showToast = Toast.makeText(login.this, "username or password is wrong", Toast.LENGTH_SHORT);
        showToast.show();
    }

    public void emptyError(){
        Toast showToast = Toast.makeText(login.this, "username and password can not be empty", Toast.LENGTH_SHORT);
        showToast.show();

    }
}
