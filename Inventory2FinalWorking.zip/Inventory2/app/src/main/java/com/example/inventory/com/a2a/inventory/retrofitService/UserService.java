package com.example.inventory.com.a2a.inventory.retrofitService;

import com.example.inventory.com.a2a.inventory.bean.User;
import com.example.inventory.com.a2a.inventory.request.LoginRequest;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface UserService {

    @POST("mobilelogin/")
    Call<User> login(@Body LoginRequest body);
}
