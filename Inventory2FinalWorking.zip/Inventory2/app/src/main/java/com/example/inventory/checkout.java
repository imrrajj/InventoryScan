package com.example.inventory;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.example.inventory.com.a2a.inventory.bean.OrderSuccess;
import com.example.inventory.com.a2a.inventory.bean.ShoppingCart;
import com.example.inventory.com.a2a.inventory.request.OrderRequest;
import com.example.inventory.com.a2a.inventory.retrofitService.OrderService;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


public class checkout  extends AppCompatActivity {

    EditText address;
    EditText telephone;
    EditText email;
    EditText name;
    RadioGroup payment_method;

    String payment_value;

    Button checkout_btn;
    Button back_cart;
    public static final String Base_login_URL = "http://look4computer.a2aweb.net/api/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.checkout);

        address =  findViewById(R.id.address);
        telephone =  findViewById(R.id.telephone);
        email =  findViewById(R.id.email);
        name =  findViewById(R.id.name);

        payment_method = findViewById(R.id.payment_method);
        payment_method.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener()
        {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId)
            {
                switch (checkedId) {
                    case R.id.cash:
                        payment_value = "cash";
                        break;
                    case R.id.paypal:
                        payment_value = "paypal";
                        break;
                    case R.id.cheque:
                        payment_value = "cheque";
                        break;
                }
            }
        });


        back_cart = findViewById(R.id.back_cart);
        back_cart.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                intent.putExtra("active_fragment","order");
                startActivity(intent);
            }
        });


        checkout_btn = findViewById(R.id.checkout_btn);
        checkout_btn.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                String address_txt = address.getText().toString();
                String telephone_txt = telephone.getText().toString();
                String email_txt = email.getText().toString();
                String name_txt = name.getText().toString();

                sendRequest(address_txt, telephone_txt, email_txt, name_txt);

            }
        });



    }

    public void hideKeyboard(View v) {

        InputMethodManager inputManager = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
        inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);

    }

    public void sendRequest(String address, String telephone, String email, String name){

        Gson gson = new GsonBuilder()
                .setDateFormat("yyyy-MM-dd'T'HH:mm:ssZ")
                .create();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Base_login_URL)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();

        OrderService orderService = retrofit.create(OrderService.class);

        Date c = Calendar.getInstance().getTime();

        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String formattedDate = df.format(c);

        String order_string = "{\"order_date\":\""+formattedDate+"\",\"customer_name\":\""+name+"\",\"customer_telephone\":\""+telephone+"\",\"customer_email\":\""+email+"\",\"customer_address\":\""+address+"\",\"payment_method\":\"123\"}";

        SharedPreferences sharedPreferences = getSharedPreferences("UserInfo", Context.MODE_PRIVATE);
        String shopping_cart_id = sharedPreferences.getString("userId","");
        String shopping_cart_str = sharedPreferences.getString(shopping_cart_id,"");

        String token = sharedPreferences.getString("token","");
        String user_id = sharedPreferences.getString("userId","");

        Call<OrderSuccess> order = orderService.new_order(new OrderRequest(order_string, shopping_cart_str),token,user_id);

        order.enqueue(new Callback<OrderSuccess>() {
            @Override
            public void onResponse(Call<OrderSuccess> call, Response<OrderSuccess> response) {

                int statusCode = response.code();

                OrderSuccess body = response.body();

                if (statusCode == 200) {
                    if (payment_value == "paypal") {
                        Intent intent = new Intent(getApplicationContext(), paypal.class);
                        intent.putExtra("EXTRA_PAYPAL_URL", body.getBase_url());
                        intent.putExtra("EXTRA_ORDER_ID", body.getOrder_id());
                        startActivity(intent);
                    } else {
                        Intent intent = new Intent(getApplicationContext(), order_success.class);
                        startActivity(intent);
                    }
                }else {
                    new AlertDialog.Builder(getApplicationContext())
                            .setTitle("SERVER ERROR")
                            .setMessage("Error: " + statusCode)

                            // Specifying a listener allows you to take an action before dismissing the dialog.
                            // The dialog is automatically dismissed when a dialog button is clicked.
                            .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    // Continue with delete operation
                                }
                            })

                            // A null listener allows the button to dismiss the dialog and take no further action.
                            .setNegativeButton(android.R.string.no, null)
                            .setIcon(android.R.drawable.ic_dialog_alert)
                            .show();
                }
            }

            @Override
            public void onFailure(Call<OrderSuccess> call, Throwable t) {

            }
        });

    }
}
