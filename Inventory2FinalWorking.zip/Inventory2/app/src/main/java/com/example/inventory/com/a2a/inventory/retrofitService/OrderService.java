package com.example.inventory.com.a2a.inventory.retrofitService;

import com.example.inventory.com.a2a.inventory.bean.OrderSuccess;
import com.example.inventory.com.a2a.inventory.bean.User;
import com.example.inventory.com.a2a.inventory.request.LoginRequest;
import com.example.inventory.com.a2a.inventory.request.OrderRequest;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface OrderService {


    @POST("new_order/")
    Call<OrderSuccess> new_order(@Body OrderRequest body, @Header("a2a-token") String token, @Header("a2a-user") String user_id);
}
