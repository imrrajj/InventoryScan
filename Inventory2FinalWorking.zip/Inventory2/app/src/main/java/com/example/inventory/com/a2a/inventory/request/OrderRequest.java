package com.example.inventory.com.a2a.inventory.request;

public class OrderRequest {
    public String order;
    public String order_products;

    public OrderRequest(String order, String order_products){

        this.order = order;
        this.order_products = order_products;

    }
}
