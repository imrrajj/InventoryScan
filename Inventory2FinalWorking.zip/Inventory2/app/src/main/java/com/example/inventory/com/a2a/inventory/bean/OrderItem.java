package com.example.inventory.com.a2a.inventory.bean;

public class OrderItem {

    public String good_id;
    public String good_name;
    public String good_quantity;
    public String good_image;
    public String good_price;

    public String getGood_id() {
        return good_id;
    }

    public void setGood_id(String good_id) {
        this.good_id = good_id;
    }

    public String getGood_name() {
        return good_name;
    }

    public void setGood_name(String good_name) {
        this.good_name = good_name;
    }

    public String getGood_quantity() {
        return good_quantity;
    }

    public void setGood_quantity(String good_quantity) {
        this.good_quantity = good_quantity;
    }

    public String getGood_image() {
        return good_image;
    }

    public void setGood_image(String good_image) {
        this.good_image = good_image;
    }

    public String getGood_price() {
        return good_price;
    }

    public void setGood_price(String good_price) {
        this.good_price = good_price;
    }
}
