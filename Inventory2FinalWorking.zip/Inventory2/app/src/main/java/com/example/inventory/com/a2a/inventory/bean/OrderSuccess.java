package com.example.inventory.com.a2a.inventory.bean;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class OrderSuccess {
    @SerializedName("success")
    @Expose
    public String success;

    @SerializedName("message")
    @Expose
    public String message;

    @SerializedName("order_id")
    @Expose
    public String order_id;

    @SerializedName("base_url")
    @Expose
    public String base_url;

    public void setSuccess(String success) {
        this.success = success;
    }
    public String getSuccess() {
        return success;
    }

    public void setMessage(String message) {
        this.message = message;
    }
    public String getMessage() {
        return message;
    }

    public void setOrder_id(String order_id) {this.order_id = order_id;    }
    public String getOrder_id() {
        return order_id;
    }

    public void setBase_url(String base_url) {
        this.base_url = base_url;
    }
    public String getBase_url() {
        return base_url;
    }



}
