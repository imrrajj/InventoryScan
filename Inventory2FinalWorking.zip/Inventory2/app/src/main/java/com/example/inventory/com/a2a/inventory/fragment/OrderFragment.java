package com.example.inventory.com.a2a.inventory.fragment;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.inventory.MainActivity;
import com.example.inventory.R;
import com.example.inventory.checkout;
import com.example.inventory.com.a2a.inventory.adapter.ShoppingCartAdapter;
import com.example.inventory.com.a2a.inventory.bean.ShoppingCart;
import com.example.inventory.com.a2a.inventory.bean.ShoppingCartItem;
import com.example.inventory.good_info_model;
import com.google.gson.Gson;

import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class OrderFragment extends Fragment {
    private ListView shopping_cart_lv;

    private ShoppingCartAdapter shoppingCartAdapter;
    private List<ShoppingCartItem> shoppingCartItemList;

    public OrderFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_order, container, false);

        shopping_cart_lv = (ListView)v.findViewById(R.id.shopping_cart_list);

        // Inflate the layout for this fragment
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("UserInfo", Context.MODE_PRIVATE);
        String shopping_cart_id = sharedPreferences.getString("userId","");
        String shopping_cart_str = sharedPreferences.getString(shopping_cart_id,"");
        Gson gson = new Gson();
        ShoppingCart shoppingCart = gson.fromJson(shopping_cart_str, ShoppingCart.class);
        shoppingCartItemList = shoppingCart.getShoppingCartItemList();

        shoppingCartAdapter = new ShoppingCartAdapter(getContext(),shoppingCartItemList);
        shopping_cart_lv.setAdapter(shoppingCartAdapter);

        shopping_cart_lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Toast showToast= Toast.makeText(getContext(),"This is position " + view.getTag() , Toast.LENGTH_SHORT);
                showToast.show();
            }
        });



        return v;
    }



}
