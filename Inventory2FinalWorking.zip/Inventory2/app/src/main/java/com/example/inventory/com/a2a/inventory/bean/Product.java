package com.example.inventory.com.a2a.inventory.bean;

import com.google.gson.annotations.SerializedName;

public class Product {
    @SerializedName("product_id")
    public String product_id;
    @SerializedName("model")
    public String model;
    @SerializedName("sku")
    public String sku;
    @SerializedName("upc")
    public String upc;
    @SerializedName("quantity")
    public String quantity_in_stock;
    @SerializedName("image")
    public String image;
    @SerializedName("price")
    public String price;
    @SerializedName("minimum")
    public String minimum;
    @SerializedName("name")
    public String product_name;
    @SerializedName("description")
    public String description;

    public String getProduct_id() {
        return product_id;
    }

    public void setProduct_id(String product_id) {
        this.product_id = product_id;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getSku() {
        return sku;
    }

    public void setSku(String sku) {
        this.sku = sku;
    }

    public String getUpc() {
        return upc;
    }

    public void setUpc(String upc) {
        this.upc = upc;
    }

    public String getQuantity_in_stock() {
        return quantity_in_stock;
    }

    public void setQuantity_in_stock(String quantity_in_stock) {
        this.quantity_in_stock = quantity_in_stock;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getMinimum() {
        return minimum;
    }

    public void setMinimum(String minimum) {
        this.minimum = minimum;
    }

    public String getProduct_name() {
        return product_name;
    }

    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }




}
