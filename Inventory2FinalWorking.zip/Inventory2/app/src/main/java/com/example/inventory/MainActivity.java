package com.example.inventory;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.example.inventory.com.a2a.inventory.fragment.HomeFragment;
import com.example.inventory.com.a2a.inventory.fragment.OrderFragment;


public class MainActivity extends FragmentActivity implements RadioGroup.OnCheckedChangeListener {

    private RadioGroup radioGroup;
    private RadioButton home;
    private RadioButton order;
    private FragmentManager fragmentManager;

    private String loginMessage;
    private String loginUserId;
    private String loginToken;

  //  public Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        /*Intent intent = new Intent(this, checkout.class);
        startActivity(intent);*/
        setContentView(R.layout.activity_main);

        SharedPreferences sharedPreferences = getSharedPreferences("UserInfo",MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        loginMessage = sharedPreferences.getString("message","");
        loginUserId = sharedPreferences.getString("userId","");
       loginToken = sharedPreferences.getString("token","");

//       if(loginMessage == "" || loginUserId == "" ||loginToken =="" ){
//           editor.putString("message","");
//            editor.putString("userId","");
//           editor.putString("token","");
//            editor.commit();
//            Intent backTologin = new Intent(MainActivity.this, login.class);
//            startActivity(backTologin);
//
//       }


       radioGroup = findViewById(R.id.main_bottom_tabs);
       home = findViewById(R.id.main_home);
        order = findViewById(R.id.main_order);
        fragmentManager = getSupportFragmentManager();
       home.setChecked(true);
        radioGroup.setOnCheckedChangeListener(this);

        String active_fragment = getIntent().getStringExtra("active_fragment");
        if(active_fragment != null && active_fragment.equals("order")) {
            changeFragment(new OrderFragment(), true);
        }else {
            changeFragment(new HomeFragment(), false);
        }
    }

    @Override
    public void onCheckedChanged(RadioGroup radioGroup, int checkedId) {

        switch (checkedId) {
            case R.id.main_home:
                changeFragment(new HomeFragment(),true);
                break;
            case R.id.main_order:
                changeFragment(new OrderFragment(),true);
                break;
        }


    }

    public void changeFragment(Fragment fragment, boolean isInit){

        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.replace(R.id.main_content, fragment);
        if(!isInit){
            transaction.addToBackStack(null);
        }
        transaction.commit();

    }

    public void new_order(View v){
        Intent intent = new Intent(v.getContext().getApplicationContext(), checkout.class);
        startActivity(intent);
    }

}
