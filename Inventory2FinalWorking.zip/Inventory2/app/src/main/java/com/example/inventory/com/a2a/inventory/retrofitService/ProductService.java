package com.example.inventory.com.a2a.inventory.retrofitService;

import com.example.inventory.com.a2a.inventory.bean.Product;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ProductService {

    @GET("{model}")
    Call<Product> searchProduct(@Path("model") String modelNumber, @Header("a2a-token") String token, @Header("a2a-user") String user_id);

}
