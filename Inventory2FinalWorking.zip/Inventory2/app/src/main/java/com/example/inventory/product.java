package com.example.rajmistry.scan;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.inventory.MainActivity;
import com.example.inventory.R;
import com.example.inventory.checkout;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class product extends AppCompatActivity {

    private Button button;
    private Button backButton;

    TextView tv;
    //String st;

    RequestQueue rq;
    TextView productIdText, modelText, skuText, upcText, quantityText, imageText, priceText, minimumText, nameText, descriptionText;

    String product_id_s, model_s, sku_s, upc_s, quantity_s, image_s, price_s, minimum_s, name_s, description_s;

    //String url = "http://look4computer.a2aweb.net/api/getproduct_sku/9501101530003";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product);


        //get the scanning result
        String st;
        tv =findViewById(R.id.productDetails);
        Intent intent = getIntent();
        st=intent.getStringExtra("Value");
        tv.setText(st);

        String url = "http://look4computer.a2aweb.net/api/getproduct_sku/"+st;

        tv.setText(st);


        //all product details from the API
        rq = Volley.newRequestQueue(this);

        productIdText = (TextView) findViewById(R.id.product_id);   //---------------------------------
        modelText = (TextView) findViewById(R.id.model);
        skuText = (TextView) findViewById(R.id.sku);
        upcText = (TextView) findViewById(R.id.upc);
        quantityText = (TextView) findViewById(R.id.quantity);
        imageText = (TextView) findViewById(R.id.image1);
        priceText = (TextView) findViewById(R.id.price);
        minimumText = (TextView) findViewById(R.id.minimum);
        nameText = (TextView) findViewById(R.id.name);
        descriptionText = (TextView) findViewById(R.id.description);

        sendjsonrequest(url);

        button = (Button) findViewById(R.id.goToCheckout);
        backButton = (Button) findViewById(R.id.backToScan);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openCheckout();
            }
        });
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                backToScan();
            }
        });



    }

    public void openCheckout(){
        Intent intent = new Intent(this,checkout.class);
        startActivity(intent);
    }
    public void backToScan(){
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
    }

   // String url = "http://look4computer.a2aweb.net/api/getproduct_sku/9501101530003";

    public void sendjsonrequest(String url) {
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    product_id_s = response.getString("product_id");  //----------------------------
                    model_s = response.getString("model");
                    sku_s = response.getString("sku");
                    upc_s = response.getString("upc");
                    quantity_s = response.getString("quantity");
                    image_s = response.getString("image");
                    price_s = response.getString("price");
                    minimum_s = response.getString("minimum");
                    name_s = response.getString("name");
                    description_s = response.getString("description");

                    productIdText.setText(product_id_s);    //------------------------------
                   modelText.setText(model_s);
                    skuText.setText(sku_s);
                    upcText.setText(upc_s);
                    quantityText.setText(quantity_s);
                    imageText.setText(image_s);
                    priceText.setText(price_s);
                    minimumText.setText(minimum_s);
                    nameText.setText(name_s);
                    descriptionText.setText(description_s);


                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }


        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("A2a-User", "1");
               params.put("A2a-Token","1b252868519876e8ac086fe6af103dfda2b4fb29fbce85fff9663a917c2a8e1b");
                return params;
            }
        };
        rq.add(jsonObjectRequest);

    }

    //button to go on checkout activity



}
