package com.example.inventory.com.a2a.inventory.retrofitService;

import com.example.inventory.com.a2a.inventory.bean.OrderPaid;
import com.example.inventory.com.a2a.inventory.bean.Product;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.Path;

public interface IsPaidService {


    @GET("is_order_paid/{order_id}")
    Call<OrderPaid> isPaid(@Path("order_id") int order_id, @Header("a2a-token") String token, @Header("a2a-user") String user_id);

}
