package com.example.inventory;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Handler;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.example.inventory.com.a2a.inventory.bean.OrderPaid;
import com.example.inventory.com.a2a.inventory.bean.OrderPaid;
import com.example.inventory.com.a2a.inventory.retrofitService.IsPaidService;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class paypal extends AppCompatActivity {

    int Order_id;
    public static final String Base_login_URL = "http://look4computer.a2aweb.net/api/";
    boolean done = false;

    String qr_url = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_paypal);

        Order_id = Integer.parseInt(getIntent().getStringExtra("EXTRA_ORDER_ID"));
        String base_url = qr_url =  getIntent().getStringExtra("EXTRA_PAYPAL_URL") + Order_id;

        ImageView imvQrCode = (ImageView)findViewById(R.id.imageView);
        Bitmap bitmap = Bitmap.createBitmap(300,300, Bitmap.Config.ALPHA_8);
        try {
            bitmap = textToImage(base_url, 300, 300);
        }catch(Exception e){

        }



        imvQrCode.setImageBitmap(bitmap);

        check_order();

    }

    public void open_qr(View v){
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(qr_url));
        startActivity(browserIntent);
    }

    private void check_order(){

        SharedPreferences sharedPreferences = getSharedPreferences("UserInfo", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        String token = sharedPreferences.getString("token","");
        String user_id = sharedPreferences.getString("userId","");

        if(done){
            return;
        }

        Gson gson = new GsonBuilder()
                .setDateFormat("yyyy-MM-dd'T'HH:mm:ssZ")
                .create();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Base_login_URL)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();

        IsPaidService paidService = retrofit.create(IsPaidService.class);


        Call<OrderPaid> call = paidService.isPaid(Order_id,token,user_id);

        call.enqueue(new Callback<OrderPaid>() {
            @Override
            public void onResponse(Call<OrderPaid> call, Response<OrderPaid> response) {

                int statusCode = response.code();

                OrderPaid body = response.body();

                if (statusCode == 200 && body.getstatus() == 1) {
                    done = true;

                    Intent intent = new Intent(getApplicationContext(), order_success.class);
                    startActivity(intent);

                }else {
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        public void run() {
                            check_order();
                        }
                    }, 5000);
                }
            }

            @Override
            public void onFailure(Call<OrderPaid> call, Throwable t) {

            }
        });


    }

    private Bitmap textToImage(String text, int width, int height) throws WriterException, NullPointerException {
        BitMatrix bitMatrix;
        try {
            bitMatrix = new MultiFormatWriter().encode(text, BarcodeFormat.DATA_MATRIX.QR_CODE,
                    width, height, null);
        } catch (IllegalArgumentException Illegalargumentexception) {
            return null;
        }

        int bitMatrixWidth = bitMatrix.getWidth();
        int bitMatrixHeight = bitMatrix.getHeight();
        int[] pixels = new int[bitMatrixWidth * bitMatrixHeight];

        int colorWhite = 0xFFFFFFFF;
        int colorBlack = 0xFF000000;

        for (int y = 0; y < bitMatrixHeight; y++) {
            int offset = y * bitMatrixWidth;
            for (int x = 0; x < bitMatrixWidth; x++) {
                pixels[offset + x] = bitMatrix.get(x, y) ? colorBlack : colorWhite;
            }
        }
        Bitmap bitmap = Bitmap.createBitmap(bitMatrixWidth, bitMatrixHeight, Bitmap.Config.ARGB_4444);

        bitmap.setPixels(pixels, 0, width, 0, 0, bitMatrixWidth, bitMatrixHeight);
        return bitmap;
    }

}
