package com.example.inventory.com.a2a.inventory.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.inventory.R;
import com.example.inventory.com.a2a.inventory.bean.ShoppingCartItem;

import java.util.List;

public class ShoppingCartAdapter extends BaseAdapter {

    private Context context;
    private List<ShoppingCartItem> shoppingCartItemList;

    public ShoppingCartAdapter(Context context, List<ShoppingCartItem> shoppingCartItemList) {
        this.context = context;
        this.shoppingCartItemList = shoppingCartItemList;
    }

    @Override
    public int getCount() {
        return shoppingCartItemList.size();
    }

    @Override
    public Object getItem(int position) {
        return shoppingCartItemList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = View.inflate(context, R.layout.shopping_cart_list_item,null);
        TextView image = (TextView)v.findViewById(R.id.shopping_cart_image);
        TextView name = (TextView)v.findViewById(R.id.shopping_cart_name);
        TextView price = (TextView)v.findViewById(R.id.shopping_cart_price);
        TextView quantity = (TextView)v.findViewById(R.id.shopping_cart_quantity);

        image.setText(shoppingCartItemList.get(position).getGood_name());
        name.setText(shoppingCartItemList.get(position).getGood_name());
        price.setText(shoppingCartItemList.get(position).getGood_price());
        quantity.setText("$" + shoppingCartItemList.get(position).getGood_quantity());
        v.setTag(shoppingCartItemList.get(position));
        return v;
    }
}
