package com.example.inventory.com.a2a.inventory.fragment;


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.inventory.R;
import com.example.inventory.com.a2a.inventory.bean.Product;
import com.example.inventory.com.a2a.inventory.retrofitService.ProductService;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends Fragment {

    EditText modelInput;
    TextView checkModelBtn;
    TextView scanBtn;
    Button logOut;
    String modelNumber;
    public static final String Base_Product_URL = "http://look4computer.a2aweb.net/api/getproduct_model/";

    public HomeFragment() {


        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_home, container, false);

        modelInput = v.findViewById(R.id.product_model_input);
        checkModelBtn = v.findViewById(R.id.product_check_btn);
        scanBtn = v.findViewById(R.id.product_scan_btn);
        logOut = v.findViewById(R.id.log_out_btn);

        checkModelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                modelNumber = modelInput.getText().toString();
                searchProductbyModel(modelNumber);
            }
        });
        scanBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchProductbyScan();
            }
        });

        logOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logOut();
            }
        });
        // Inflate the layout for this fragment
        return v;

    }

    public void searchProductbyScan(){
        Intent intent = new Intent(getActivity().getApplication(),com.example.inventory.scan.class);
        startActivity(intent);
    }
    public void logOut(){
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("UserInfo", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.commit();
        Intent intent = new Intent(getActivity().getApplication(),com.example.inventory.login.class);
        startActivity(intent);

    }

    public void searchProductbyModel(String modelNumber){

        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("UserInfo", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        String token = sharedPreferences.getString("token","");
        String user_id = sharedPreferences.getString("userId","");
        Gson gson = new GsonBuilder()
                .setDateFormat("yyyy-MM-dd'T'HH:mm:ssZ")
                .create();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Base_Product_URL)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();

        ProductService productService = retrofit.create(ProductService.class);
        Call<Product> searchProduct = productService.searchProduct(modelNumber,token,user_id);
        searchProduct.enqueue(new Callback<Product>() {
            @Override
            public void onResponse(Call<Product> call, Response<Product> response) {
                int statusCode = response.code();
                Product product = response.body();
                Bundle bundle  = new Bundle();
                bundle.putString("product_id", product.getProduct_id());
                bundle.putString("model", product.getModel());
                bundle.putString("sku", product.getSku());
                bundle.putString("upc", product.getUpc());
                bundle.putString("quantity", product.getQuantity_in_stock());
                bundle.putString("image", product.getImage());
                bundle.putString("price",product.getPrice());
                bundle.putString("minimum",product.getMinimum());
                bundle.putString("name",product.getProduct_name());
                bundle.putString("description", product.getDescription());
                Intent intent = new Intent(getActivity().getApplication(),com.example.inventory.good_info_model.class);
                intent.putExtra("product",bundle);
                startActivity(intent);
            }

            @Override
            public void onFailure(Call<Product> call, Throwable t) {

            }
        });
    }
}
